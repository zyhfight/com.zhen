package ServiceInterface;

public interface usrInterface {
	public int checkIdentity(String sql);
	public boolean addUsr(Object obj);
	public boolean deleteUsr(String str);

}
