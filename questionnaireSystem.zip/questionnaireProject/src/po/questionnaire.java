package po;

public class questionnaire {
	private String WID;
	private String subject;
	private String stemNum;
	private String teaID;
	private String createTime;
	public String getWID() {
		return WID;
	}
	public void setWID(String wID) {
		WID = wID;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getStemNum() {
		return stemNum;
	}
	public void setStemNum(String stemNum) {
		this.stemNum = stemNum;
	}
	public String getTeaID() {
		return teaID;
	}
	public void setTeaID(String teaID) {
		this.teaID = teaID;
	}
	public String getCreateTime() {
		return createTime;
	}
	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}
	
}
