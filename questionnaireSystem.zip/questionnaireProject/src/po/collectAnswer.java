package po;

public class collectAnswer {
	private String WID;
	private String TIDNO;
	private String ANSWERID;
	private String STUID;
	private String ANSWERTIME;
	private String TEAID;
	private String ACTIVITY;
	
	public String getACTIVITY() {
		return ACTIVITY;
	}
	public void setACTIVITY(String aCTIVITY) {
		ACTIVITY = aCTIVITY;
	}
	public String getTEAID() {
		return TEAID;
	}
	public void setTEAID(String tEAID) {
		TEAID = tEAID;
	}
	public String getWID() {
		return WID;
	}
	public void setWID(String wID) {
		WID = wID;
	}
	
	public String getTIDNO() {
		return TIDNO;
	}
	public void setTIDNO(String tIDNO) {
		TIDNO = tIDNO;
	}
	public String getANSWERID() {
		return ANSWERID;
	}
	public void setANSWERID(String aNSWERID) {
		ANSWERID = aNSWERID;
	}
	public String getSTUID() {
		return STUID;
	}
	public void setSTUID(String sTUID) {
		STUID = sTUID;
	}
	public String getANSWERTIME() {
		return ANSWERTIME;
	}
	public void setANSWERTIME(String aNSWERTIME) {
		ANSWERTIME = aNSWERTIME;
	}
	
}
