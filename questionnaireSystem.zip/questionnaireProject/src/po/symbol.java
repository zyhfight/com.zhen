package po;

public class symbol {
	private String FEATURE;
	private String TEAID;
	public String getFEATURE() {
		return FEATURE;
	}
	public void setFEATURE(String fEATURE) {
		FEATURE = fEATURE;
	}
	public String getTEAID() {
		return TEAID;
	}
	public void setTEAID(String tEAID) {
		TEAID = tEAID;
	}
	
	
}
