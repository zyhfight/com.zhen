package po;

public class answer {
	private String answerID;
	private String content;
	private String teaID;
	public String getAnswerID() {
		return answerID;
	}
	public void setAnswerID(String answerID) {
		this.answerID = answerID;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getTeaID() {
		return teaID;
	}
	public void setTeaID(String teaID) {
		this.teaID = teaID;
	}
	
}
