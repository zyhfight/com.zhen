package po;

public class SELECTQUESTION {
	private String WID;
	private String TIDNO;
	private String TID;
	public String getWID() {
		return WID;
	}
	public void setWID(String wID) {
		WID = wID;
	}
	public String getTIDNO() {
		return TIDNO;
	}
	public void setTIDNO(String tIDNO) {
		TIDNO = tIDNO;
	}
	public String getTID() {
		return TID;
	}
	public void setTID(String tID) {
		TID = tID;
	}
	
}
