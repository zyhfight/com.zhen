package po;

public class student {
	private String stuID;
	private String stuClass;
	private String stuName;
	private String stuMail;
	private String stuTelphone;
	private String stuMajor;
	private String stuSchool;
	public String getStuID() {
		return stuID;
	}
	public void setStuID(String stuID) {
		this.stuID = stuID;
	}
	public String getStuClass() {
		return stuClass;
	}
	public void setStuClass(String stuClass) {
		this.stuClass = stuClass;
	}
	public String getStuName() {
		return stuName;
	}
	public void setStuName(String stuName) {
		this.stuName = stuName;
	}
	public String getStuMail() {
		return stuMail;
	}
	public void setStuMail(String stuMail) {
		this.stuMail = stuMail;
	}
	public String getStuTelphone() {
		return stuTelphone;
	}
	public void setStuTelphone(String stuTelphone) {
		this.stuTelphone = stuTelphone;
	}
	public String getStuMajor() {
		return stuMajor;
	}
	public void setStuMajor(String stuMajor) {
		this.stuMajor = stuMajor;
	}
	public String getStuSchool() {
		return stuSchool;
	}
	public void setStuSchool(String stuSchool) {
		this.stuSchool = stuSchool;
	}
	
}
