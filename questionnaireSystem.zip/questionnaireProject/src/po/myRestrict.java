package po;

public class myRestrict {
	private String WID;
	private String crisisTID;
	private String crisisPID;
	private String startTID;
	private String endTID;
	public String getWID() {
		return WID;
	}
	public void setWID(String wID) {
		WID = wID;
	}
	public String getCrisisTID() {
		return crisisTID;
	}
	public void setCrisisTID(String crisisTID) {
		this.crisisTID = crisisTID;
	}
	public String getCrisisPID() {
		return crisisPID;
	}
	public void setCrisisPID(String crisisPID) {
		this.crisisPID = crisisPID;
	}
	public String getStartTID() {
		return startTID;
	}
	public void setStartTID(String startTID) {
		this.startTID = startTID;
	}
	public String getEndTID() {
		return endTID;
	}
	public void setEndTID(String endTID) {
		this.endTID = endTID;
	}
	
}
