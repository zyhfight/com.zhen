package po;

public class survey {
	private String WID;
	private String ACTIVITY;
	private String STARTTIME;
	private String ENDTIME;
	private String MYGROUP;
	private String TEAID;
	public String getWID() {
		return WID;
	}
	public void setWID(String wID) {
		WID = wID;
	}
	public String getACTIVITY() {
		return ACTIVITY;
	}
	public void setACTIVITY(String aCTIVITY) {
		ACTIVITY = aCTIVITY;
	}
	public String getSTARTTIME() {
		return STARTTIME;
	}
	public void setSTARTTIME(String sTARTTIME) {
		STARTTIME = sTARTTIME;
	}
	public String getENDTIME() {
		return ENDTIME;
	}
	public void setENDTIME(String eNDTIME) {
		ENDTIME = eNDTIME;
	}
	public String getMYGROUP() {
		return MYGROUP;
	}
	public void setMYGROUP(String mYGROUP) {
		MYGROUP = mYGROUP;
	}
	public String getTEAID() {
		return TEAID;
	}
	public void setTEAID(String tEAID) {
		TEAID = tEAID;
	}
	
	
}
