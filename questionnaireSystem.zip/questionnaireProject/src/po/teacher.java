package po;

public class teacher {
	private String teaID;
	private String teaName;
	private String teaMail;
	private String TEATELPHONEL;
	public String getTeaID() {
		return teaID;
	}
	public void setTeaID(String teaID) {
		this.teaID = teaID;
	}
	public String getTeaName() {
		return teaName;
	}
	public void setTeaName(String teaName) {
		this.teaName = teaName;
	}
	public String getTeaMail() {
		return teaMail;
	}
	public void setTeaMail(String teaMail) {
		this.teaMail = teaMail;
	}
	public String getTEATELPHONEL() {
		return TEATELPHONEL;
	}
	public void setTEATELPHONEL(String tEATELPHONEL) {
		TEATELPHONEL = tEATELPHONEL;
	}
	
}
